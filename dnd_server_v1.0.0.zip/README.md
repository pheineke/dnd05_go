# Ideen für Änderungen

- Schriftfarbe ändern
- Schriftart ändern